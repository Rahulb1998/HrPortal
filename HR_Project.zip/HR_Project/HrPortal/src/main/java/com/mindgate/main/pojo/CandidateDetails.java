package com.mindgate.main.pojo;

public class CandidateDetails {
	private int candidateId;
	private String skill1;
	private String skill2;
	private String skill3;
	private String qualification;
	private String experience;
	private String status;
	private RequirementRequestDetails requirementrequestetails;

	public CandidateDetails() {
		// TODO Auto-generated constructor stub
	}

	public CandidateDetails(int candidateId, String skill1, String skill2, String skill3, String qualification,
			String experience, String status, RequirementRequestDetails requirementrequestetails) {
		super();
		this.candidateId = candidateId;
		this.skill1 = skill1;
		this.skill2 = skill2;
		this.skill3 = skill3;
		this.qualification = qualification;
		this.experience = experience;
		this.status = status;
		this.requirementrequestetails = requirementrequestetails;
	}

	public int getCandidateId() {
		return candidateId;
	}

	public void setCandidateId(int candidateId) {
		this.candidateId = candidateId;
	}

	public String getSkill1() {
		return skill1;
	}

	public void setSkill1(String skill1) {
		this.skill1 = skill1;
	}

	public String getSkill2() {
		return skill2;
	}

	public void setSkill2(String skill2) {
		this.skill2 = skill2;
	}

	public String getSkill3() {
		return skill3;
	}

	public void setSkill3(String skill3) {
		this.skill3 = skill3;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public RequirementRequestDetails getRequirementrequestetails() {
		return requirementrequestetails;
	}

	public void setRequirementrequestetails(RequirementRequestDetails requirementrequestetails) {
		this.requirementrequestetails = requirementrequestetails;
	}

	@Override
	public String toString() {
		return "CandidateDetails [candidateId=" + candidateId + ", skill1=" + skill1 + ", skill2=" + skill2
				+ ", skill3=" + skill3 + ", qualification=" + qualification + ", experience=" + experience + ", status="
				+ status + ", requirementrequestetails=" + requirementrequestetails + "]";
	}

}
