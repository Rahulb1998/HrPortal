package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.pojo.CandidateDetails;

public interface CandidateDetailsRepositoryInterface {
	
	public boolean addNewCandidate(CandidateDetails candidateDetails);
	public boolean updateCandidate(CandidateDetails candidateDetails);
	public boolean deleteCandidate(int CandidateId);
	public CandidateDetails getCandidateDetailsByCandidateId(int CandidateId );
	public List<CandidateDetails> getAllCandidateDetails();


}
