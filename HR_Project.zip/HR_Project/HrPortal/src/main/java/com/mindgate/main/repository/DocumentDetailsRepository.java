package com.mindgate.main.repository;

public class DocumentDetailsRepository implements DocumentDetailsRepositoryInterface{
	

}
