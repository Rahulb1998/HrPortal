package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.pojo.CandidateDetails;

public class CandidateDetailsRepository implements CandidateDetailsRepositoryInterface {

	@Override
	public boolean addNewCandidate(CandidateDetails candidateDetails) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateCandidate(CandidateDetails candidateDetails) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCandidate(int CandidateId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public CandidateDetails getCandidateDetailsByCandidateId(int CandidateId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<CandidateDetails> getAllCandidateDetails() {
		// TODO Auto-generated method stub
		return null;
	}

}
